For 2025-08-31, projected **injections = 58.20 Bcf** and **withdrawals = -0.00 Bcf** (net gap delta 1.72 Bcf).
The blended estimator emphasized **Method C (Ops)** due to recent nominations/injections during the gap window.

Hotspots:
- Region: **US** (none).
  Driver: South-Central salt variability; recommend adjusting nominations by **0.10 Bcf** under **cold-snap** scenario.

Operational asks:
- Confirm ops file coverage for 2 gap day(s).
- Validate tariff assumptions (inj 0.02, wd 0.03).
- Flag any expected imbalance penalties beyond the base estimate.