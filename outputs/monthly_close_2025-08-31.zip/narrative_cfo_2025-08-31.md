As of 2025-08-31, estimated working gas is **3,252 Bcf**, which is **85.6% of working capacity**.
We used the **Base** scenario with blended estimator weights **C:A:B = 0.5:0.3:0.2**, projecting **2** gap day(s) from the last EIA Friday report.

**Accrual summary (USD):** Inventory **$10,960,135,330**, Variable fees **$1,207,068**, Fixed demand **$120,000**, Penalties (expected) **$0**.
Total Base accrual **$10,961,462,398**, with sensitivity band ±10.0% (**$9,865,316,159 – $12,057,608,638**).

Context: storage stands **near the 5-year average** relative to the 5-year average; risk this month is primarily driven by **South-Central salt variability**. We expect any true-up to fall within the sensitivity band.